# Shieldwise AI

Shieldwise AI is a local-first chat website for general conversations and financial education. It uses a locally running Ollama model and includes chat history, finance-aware response structure, and finance visual explainers.

## Requirements

- Node.js 18 or later
- [Ollama](https://ollama.com/) running locally
- The `gemma3:1b` model installed:

```powershell
ollama pull gemma3:1b
```

## Run locally

```powershell
node server.mjs
```

Open `http://localhost:8787` in a browser. On Windows, you can also run `Start Shieldwise.cmd`.

## What it does

- General-purpose local AI chat
- Financial education and scam-safety guidance
- Local conversation history stored in browser storage
- Finance-only visual explainer generation
- A same-origin server proxy to the local Ollama API, avoiding browser CORS issues

## Safety

Shieldwise provides educational information, not personalised financial, legal, tax, or investment advice. Do not enter OTPs, PINs, passwords, account numbers, or full card details.

## Publish on GitHub

1. Create a new public repository on GitHub.
2. Upload these project files or push this folder with Git.
3. Include the requirements above in the repository description or README.

The public repository contains only the website code. Every user must run Ollama locally; no model, credentials, or chat history is included.
