# Public deployment checklist

This project is ready to deploy as a Node service. A public deployment still requires a server-side AI provider.

## Required configuration

Set these environment variables in your host’s dashboard:

```text
OLLAMA_URL=https://your-private-ollama-host/api/chat
OLLAMA_MODEL=gemma3:1b
```

Do **not** expose an unauthenticated Ollama endpoint to the internet. Put it behind a private network, VPN, gateway, or authentication layer. The browser only talks to this Node server; the Node server talks to the AI provider.

## Deploy

1. Create a public GitHub repository from this project.
2. Deploy it as a Node service on your chosen host.
3. Set the start command to `node server.mjs`.
4. Add `OLLAMA_URL` and `OLLAMA_MODEL` as server secrets/environment variables.
5. Verify `/` loads and send a test prompt.

## Important

GitHub Pages is static hosting and cannot run `server.mjs`, so it cannot provide the AI chat service. Use a Node-capable host for the public site.
