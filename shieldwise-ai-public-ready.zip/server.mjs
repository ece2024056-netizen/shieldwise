import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { join, extname, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('.', import.meta.url));
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };
const ollamaUrl = process.env.OLLAMA_URL || 'http://127.0.0.1:11434/api/chat';
const ollamaModel = process.env.OLLAMA_MODEL || 'gemma3:1b';
createServer((req, res) => {
  const path = new URL(req.url, 'http://localhost').pathname;
  if (path === '/api/chat' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
      try {
        const request = JSON.parse(body);
        request.model = ollamaModel;
        const upstream = await fetch(ollamaUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(request) });
        res.writeHead(upstream.status, { 'Content-Type': 'application/json' }); res.end(await upstream.text());
      } catch { res.writeHead(503, { 'Content-Type': 'application/json' }); res.end('{"error":"AI service is unavailable. Check the server AI configuration."}'); }
    }); return;
  }
  const safe = normalize(path === '/' ? 'index.html' : path.slice(1)).replace(/^([.][.][\\/])+/, '');
  readFile(join(root, safe)).then(file => {
    if (safe === 'index.html') file = Buffer.from(file.toString().replace('</body>', '<script src="/features.js"></script></body>'));
    res.writeHead(200, { 'Content-Type': types[extname(safe)] || 'application/octet-stream', 'Cache-Control': 'no-store' }); res.end(file);
  }).catch(() => { res.writeHead(404); res.end('Not found'); });
}).listen(8787, '127.0.0.1', () => console.log('Shieldwise ready: http://localhost:8787'));
