(() => {
  const css = document.createElement('style');
  css.textContent = `.visual-btn{margin-top:13px;border:1px solid #b98c39;background:#fff8e9;color:#75551d;border-radius:6px;padding:8px 11px;font:700 12px "Segoe UI",sans-serif;cursor:pointer}.visual-btn:hover{background:#fff0cb}.visual-modal{position:fixed;inset:0;background:#0d2921bb;z-index:30;display:grid;place-items:center;padding:24px}.visual-card{background:#fff;width:min(900px,100%);max-height:90vh;overflow:auto;border-radius:12px;padding:21px;font-family:"Segoe UI",sans-serif;box-shadow:0 22px 70px #0005}.visual-card h2{font-family:Georgia,serif;margin:0 0 5px}.visual-card p{color:#65756b;margin:0 0 14px}.visual-card img{width:100%;border:1px solid #d8e3da;background:#f8faf7}.visual-card button{float:right;border:0;background:#edf2ee;border-radius:5px;padding:7px 10px;font-weight:700;cursor:pointer}`;
  document.head.appendChild(css);
  const intro = document.querySelector('.intro');
  if (!intro) return;
  const button = document.createElement('button'); button.className = 'visual-btn'; button.textContent = '▧ Generate financial visual'; intro.appendChild(button);
  const money = /bank|budget|saving|debt|loan|invest|stock|mutual|fraud|scam|upi|atm|tax|insurance|cashflow|income|expense|financial|inflation|interest/i;
  const fallback = (title) => `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="720" viewBox="0 0 1200 720"><rect width="1200" height="720" fill="#f7faf7"/><rect x="55" y="45" width="1090" height="630" rx="22" fill="#ffffff" stroke="#d9e5dc"/><text x="105" y="125" font-family="Georgia" font-size="38" fill="#153d30">${title.replace(/[<>&]/g,'')}</text><text x="105" y="163" font-family="Arial" font-size="18" fill="#6a7a70">Financial explainer · use as a discussion aid</text><line x1="105" x2="1090" y1="205" y2="205" stroke="#d9e5dc"/><circle cx="245" cy="380" r="105" fill="#e7f5eb"/><path d="M245 275 A105 105 0 0 1 344 412 L245 380Z" fill="#176b4c"/><path d="M245 380 L344 412 A105 105 0 0 1 176 456Z" fill="#d8ad55"/><text x="170" y="555" font-family="Arial" font-size="20" fill="#1c3329">Review the inputs</text><rect x="500" y="275" width="500" height="75" rx="12" fill="#e8f5ed"/><rect x="500" y="380" width="400" height="75" rx="12" fill="#fff4d8"/><rect x="500" y="485" width="310" height="75" rx="12" fill="#eef3ef"/><text x="530" y="322" font-family="Arial" font-size="21" fill="#174c39">1. Understand the situation</text><text x="530" y="427" font-family="Arial" font-size="21" fill="#715319">2. Compare risks and options</text><text x="530" y="532" font-family="Arial" font-size="21" fill="#354b40">3. Verify before acting</text></svg>`;
  button.onclick = async () => {
    const prompt = window.prompt('Describe the financial visual you need. Example: "A diagram explaining how to recover after UPI fraud"');
    if (!prompt) return;
    if (!money.test(prompt)) { alert('This tool is limited to finance, banking, investing, budgeting, and scam-safety visuals.'); return; }
    const modal = document.createElement('div'); modal.className = 'visual-modal'; modal.innerHTML = '<div class="visual-card"><button>Close</button><h2>Preparing visual…</h2><p>Generating a financial explainer.</p></div>'; document.body.appendChild(modal); modal.querySelector('button').onclick = () => modal.remove();
    let svg;
    try {
      const response = await fetch('/api/chat', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({model:'gemma3:1b',stream:false,options:{temperature:.2},messages:[{role:'system',content:'Return ONLY a complete safe SVG. Create a professional 1200x720 financial infographic with a title, labels, and 3-5 explanatory elements. Navy, teal, gold and white palette. No scripts, external URLs, markdown, or explanations.'},{role:'user',content:prompt}]}) });
      const data = await response.json(); svg = (data.message?.content || '').match(/<svg[\s\S]*<\/svg>/i)?.[0];
    } catch {}
    svg = (svg || fallback(prompt)).replace(/<script[\s\S]*?<\/script>/gi,'');
    modal.querySelector('.visual-card').innerHTML = '<button>Close</button><h2>Financial visual</h2><p>'+prompt.replace(/[<>&]/g,'')+'</p><img alt="Financial explainer" src="data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg)+'">'; modal.querySelector('button').onclick = () => modal.remove();
  };
})();
