@echo off
cd /d "%~dp0"
echo Starting Shieldwise at http://localhost:8787
node server.mjs
